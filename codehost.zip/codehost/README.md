# CodeHost - Site de Hospedagem de Bots

Site estático completo para venda de planos de RAM para bots.

## Planos
- **2 GB** → R$ 9,63 / 30 dias
- **4 GB** → R$ 13,96 / 30 dias
- **10 GB** → R$ 24,33 / 30 dias

## Funcionalidades
- Cadastro e Login (LocalStorage)
- Reconhecimento automático do dono pelo e-mail `daviluccas201400@gmail.com`
- Geração de PIX + QR Code com a chave **84996762508**
- Botão “Falar com Atendente” (WhatsApp)
- Painel do dono para definir data de expiração dos planos
- Dashboard do usuário mostrando status e data de validade

## Como hospedar no GitHub Pages
1. Crie um repositório no GitHub
2. Faça upload de todos os arquivos desta pasta
3. Vá em Settings → Pages → Source: Deploy from a branch → main / root
4. Pronto! O site estará no ar.

## Observações importantes
- Este é um sistema **estático** (frontend apenas).
- Os dados dos usuários ficam salvos no navegador de cada pessoa (LocalStorage).
- Para ter um banco de dados real compartilhado entre todos, é necessário um backend.
- O pagamento é manual via PIX + confirmação no WhatsApp.
- O dono libera o plano manualmente pelo painel admin.

## Estrutura
```
codehost/
├── index.html
├── login.html
├── register.html
├── dashboard.html
├── payment.html
├── admin.html
├── css/style.css
├── js/
│   ├── database.js
│   ├── pix.js
│   └── app.js
└── README.md
```
