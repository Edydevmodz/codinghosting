// pix.js - Gera payload PIX estático + QR Code (chave telefone 84996762508)

function crc16(payload) {
  let crc = 0xFFFF;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
      crc &= 0xFFFF;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function emv(id, value) {
  const len = String(value.length).padStart(2, "0");
  return id + len + value;
}

function generatePixPayload(amount, description = "CodeHost Plano") {
  const key = "+5584996762508"; // Chave PIX telefone
  const name = "CODEHOST";
  const city = "NATAL";

  const merchantAccount =
    emv("00", "BR.GOV.BCB.PIX") +
    emv("01", key) +
    emv("02", description.substring(0, 50));

  let payload =
    emv("00", "01") +
    emv("26", merchantAccount) +
    emv("52", "0000") +
    emv("53", "986") +
    (amount > 0 ? emv("54", amount.toFixed(2)) : "") +
    emv("58", "BR") +
    emv("59", name) +
    emv("60", city) +
    emv("62", emv("05", "***")) +
    "6304";

  const crc = crc16(payload);
  return payload + crc;
}

// Gera QR Code usando API pública (qrserver) - funciona offline depois de carregar
function renderPixQRCode(elementId, amount, description) {
  const payload = generatePixPayload(amount, description);
  const el = document.getElementById(elementId);
  if (!el) return payload;

  // Usa API gratuita para gerar a imagem do QR
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(payload)}`;
  el.innerHTML = `<img src="${qrUrl}" alt="QR Code PIX" width="220" height="220">`;
  
  return payload;
}

window.CodeHostPIX = {
  generatePixPayload,
  renderPixQRCode
};
