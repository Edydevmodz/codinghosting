// database.js - Simula o banco de dados dos usuários (LocalStorage + estrutura)
// O dono é reconhecido pelo e-mail: daviluccas201400@gmail.com

const OWNER_EMAIL = "daviluccas201400@gmail.com";

const PLANS = {
  "2gb": { name: "2 GB RAM", price: 9.63, ram: 2, days: 30 },
  "4gb": { name: "4 GB RAM", price: 13.96, ram: 4, days: 30 },
  "10gb": { name: "10 GB RAM", price: 24.33, ram: 10, days: 30 }
};

function getUsers() {
  const data = localStorage.getItem("codehost_users");
  return data ? JSON.parse(data) : [];
}

function saveUsers(users) {
  localStorage.setItem("codehost_users", JSON.stringify(users));
}

function getCurrentUser() {
  const email = localStorage.getItem("codehost_current");
  if (!email) return null;
  const users = getUsers();
  return users.find(u => u.email === email) || null;
}

function setCurrentUser(email) {
  if (email) {
    localStorage.setItem("codehost_current", email);
  } else {
    localStorage.removeItem("codehost_current");
  }
}

function registerUser(name, email, password, phone = "") {
  const users = getUsers();
  if (users.find(u => u.email === email)) {
    return { success: false, message: "E-mail já cadastrado!" };
  }

  const isOwner = email.toLowerCase() === OWNER_EMAIL.toLowerCase();

  const newUser = {
    id: Date.now().toString(),
    name,
    email: email.toLowerCase(),
    password, // Em produção real nunca salve assim! Aqui é só demonstração local.
    phone,
    plan: isOwner ? "10gb" : null,
    planExpires: isOwner ? "2099-12-31" : null,
    isOwner,
    createdAt: new Date().toISOString(),
    paymentStatus: isOwner ? "paid" : "none"
  };

  users.push(newUser);
  saveUsers(users);
  setCurrentUser(newUser.email);
  return { success: true, user: newUser };
}

function loginUser(email, password) {
  const users = getUsers();
  const user = users.find(u => u.email === email.toLowerCase() && u.password === password);
  if (!user) {
    return { success: false, message: "E-mail ou senha incorretos." };
  }
  setCurrentUser(user.email);
  return { success: true, user };
}

function logoutUser() {
  setCurrentUser(null);
}

function updateUserPlan(email, planKey, expiresDate) {
  const users = getUsers();
  const idx = users.findIndex(u => u.email === email.toLowerCase());
  if (idx === -1) return false;

  users[idx].plan = planKey;
  users[idx].planExpires = expiresDate;
  users[idx].paymentStatus = "paid";
  saveUsers(users);
  return true;
}

function isPlanActive(user) {
  if (!user || !user.planExpires) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const expires = new Date(user.planExpires);
  return expires >= today;
}

// Exporta para uso global
window.CodeHostDB = {
  OWNER_EMAIL,
  PLANS,
  getUsers,
  saveUsers,
  getCurrentUser,
  setCurrentUser,
  registerUser,
  loginUser,
  logoutUser,
  updateUserPlan,
  isPlanActive
};
