// app.js - Lógica principal do CodeHost

document.addEventListener("DOMContentLoaded", () => {
  updateHeader();
});

function updateHeader() {
  const user = CodeHostDB.getCurrentUser();
  const nav = document.getElementById("nav-links");
  if (!nav) return;

  if (user) {
    let html = `
      <a href="dashboard.html">Dashboard</a>
      ${user.isOwner ? '<a href="admin.html">Painel Dono</a>' : ''}
      <a href="#" onclick="doLogout()">Sair (${user.name.split(' ')[0]})</a>
    `;
    nav.innerHTML = html;
  } else {
    nav.innerHTML = `
      <a href="login.html">Entrar</a>
      <a href="register.html" class="btn btn-primary" style="margin-left:12px;padding:8px 16px;">Cadastrar</a>
    `;
  }
}

function doLogout() {
  CodeHostDB.logoutUser();
  window.location.href = "index.html";
}

function formatPrice(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function formatDate(dateStr) {
  if (!dateStr) return "—";
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("pt-BR");
}

// ===== Registro =====
function handleRegister(e) {
  e.preventDefault();
  const name = document.getElementById("reg-name").value.trim();
  const email = document.getElementById("reg-email").value.trim();
  const phone = document.getElementById("reg-phone").value.trim();
  const password = document.getElementById("reg-password").value;

  if (!name || !email || !password) {
    showAlert("register-alert", "Preencha todos os campos obrigatórios.", "error");
    return;
  }

  const result = CodeHostDB.registerUser(name, email, password, phone);
  if (result.success) {
    showAlert("register-alert", "Cadastro realizado com sucesso! Redirecionando...", "success");
    setTimeout(() => {
      window.location.href = "dashboard.html";
    }, 1200);
  } else {
    showAlert("register-alert", result.message, "error");
  }
}

// ===== Login =====
function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;

  const result = CodeHostDB.loginUser(email, password);
  if (result.success) {
    showAlert("login-alert", "Login realizado! Redirecionando...", "success");
    setTimeout(() => {
      window.location.href = result.user.isOwner ? "admin.html" : "dashboard.html";
    }, 1000);
  } else {
    showAlert("login-alert", result.message, "error");
  }
}

function showAlert(id, message, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.className = `alert alert-${type}`;
  el.textContent = message;
  el.classList.remove("hidden");
}

// ===== Escolher plano =====
function choosePlan(planKey) {
  const user = CodeHostDB.getCurrentUser();
  if (!user) {
    alert("Você precisa estar logado para comprar um plano.");
    window.location.href = "login.html";
    return;
  }
  localStorage.setItem("codehost_selected_plan", planKey);
  window.location.href = "payment.html";
}

// ===== Página de pagamento =====
function initPaymentPage() {
  const user = CodeHostDB.getCurrentUser();
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  const planKey = localStorage.getItem("codehost_selected_plan") || "2gb";
  const plan = CodeHostDB.PLANS[planKey];
  if (!plan) {
    window.location.href = "index.html";
    return;
  }

  document.getElementById("plan-name").textContent = plan.name;
  document.getElementById("plan-price").textContent = formatPrice(plan.price);
  document.getElementById("plan-days").textContent = plan.days + " dias";

  const payload = CodeHostPIX.renderPixQRCode("qrcode", plan.price, `CodeHost ${plan.name}`);
  document.getElementById("pix-copia-cola").textContent = payload;
  document.getElementById("pix-copia-cola").onclick = () => {
    navigator.clipboard.writeText(payload);
    alert("Código PIX copiado!");
  };
}

// ===== Dashboard =====
function initDashboard() {
  const user = CodeHostDB.getCurrentUser();
  if (!user) {
    window.location.href = "login.html";
    return;
  }

  document.getElementById("user-name").textContent = user.name;
  document.getElementById("user-email").textContent = user.email;

  const planBox = document.getElementById("plan-info");
  if (user.plan && CodeHostDB.isPlanActive(user)) {
    const plan = CodeHostDB.PLANS[user.plan];
    planBox.innerHTML = `
      <p><strong>Plano atual:</strong> ${plan ? plan.name : user.plan}</p>
      <p><strong>Status:</strong> <span class="status-active">Ativo</span></p>
      <p><strong>Expira em:</strong> ${formatDate(user.planExpires)}</p>
    `;
  } else if (user.plan) {
    planBox.innerHTML = `
      <p><strong>Plano:</strong> ${user.plan}</p>
      <p><strong>Status:</strong> <span class="status-expired">Expirado</span></p>
      <p><strong>Expirou em:</strong> ${formatDate(user.planExpires)}</p>
      <a href="index.html" class="btn btn-primary mt-20">Renovar plano</a>
    `;
  } else {
    planBox.innerHTML = `
      <p>Você ainda não possui um plano ativo.</p>
      <a href="index.html" class="btn btn-primary mt-20">Ver planos</a>
    `;
  }

  if (user.isOwner) {
    document.getElementById("owner-badge").classList.remove("hidden");
  }
}

// ===== Admin =====
function initAdmin() {
  const user = CodeHostDB.getCurrentUser();
  if (!user || !user.isOwner) {
    alert("Acesso restrito ao dono.");
    window.location.href = "dashboard.html";
    return;
  }

  renderAdminTable();
}

function renderAdminTable() {
  const users = CodeHostDB.getUsers();
  const tbody = document.getElementById("admin-tbody");
  tbody.innerHTML = "";

  users.forEach(u => {
    const tr = document.createElement("tr");
    const active = CodeHostDB.isPlanActive(u);
    tr.innerHTML = `
      <td>${u.name}</td>
      <td>${u.email}</td>
      <td>${u.plan ? (CodeHostDB.PLANS[u.plan]?.name || u.plan) : "—"}</td>
      <td>
        <input type="date" value="${u.planExpires || ""}" 
               onchange="changeExpire('${u.email}', this.value)" 
               ${u.isOwner ? "disabled" : ""}>
      </td>
      <td class="${active ? "status-active" : "status-expired"}">
        ${active ? "Ativo" : (u.plan ? "Expirado" : "Sem plano")}
      </td>
      <td>
        ${u.isOwner ? "<em>Dono</em>" : `
          <select onchange="changePlan('${u.email}', this.value)">
            <option value="">Sem plano</option>
            <option value="2gb" ${u.plan === "2gb" ? "selected" : ""}>2 GB</option>
            <option value="4gb" ${u.plan === "4gb" ? "selected" : ""}>4 GB</option>
            <option value="10gb" ${u.plan === "10gb" ? "selected" : ""}>10 GB</option>
          </select>
        `}
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function changeExpire(email, date) {
  const users = CodeHostDB.getUsers();
  const u = users.find(x => x.email === email);
  if (!u) return;
  CodeHostDB.updateUserPlan(email, u.plan || "2gb", date);
  renderAdminTable();
}

function changePlan(email, planKey) {
  if (!planKey) {
    const users = CodeHostDB.getUsers();
    const idx = users.findIndex(x => x.email === email);
    if (idx >= 0) {
      users[idx].plan = null;
      users[idx].planExpires = null;
      users[idx].paymentStatus = "none";
      CodeHostDB.saveUsers(users);
    }
  } else {
    // Define 30 dias a partir de hoje
    const d = new Date();
    d.setDate(d.getDate() + 30);
    const expires = d.toISOString().split("T")[0];
    CodeHostDB.updateUserPlan(email, planKey, expires);
  }
  renderAdminTable();
}

window.doLogout = doLogout;
window.handleRegister = handleRegister;
window.handleLogin = handleLogin;
window.choosePlan = choosePlan;
window.initPaymentPage = initPaymentPage;
window.initDashboard = initDashboard;
window.initAdmin = initAdmin;
window.changeExpire = changeExpire;
window.changePlan = changePlan;
